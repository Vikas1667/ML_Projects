from flask import Flask, render_template, request
from preprocess import preprocess
from keyphrase_extractor import candidate_keyword

app = Flask(__name__)

@app.route('/')
def hello():
    print("hello")
    return render_template('index.html')


@app.route('/predict', methods=['POST', 'GET'])
def predict(text):
    print("starting")
    text = request.form['text']
    print('input',text)
    data = preprocess(text['data'])
    # print('preprocessed',text)
    # results= candidate_keyword(text)
    # print('output',results)
    return data


if __name__== "__main__":
    app.run(debug=True)